const products = [
 {id:1,name:"AuraView 55” 4K Smart TV",category:"TV",price:32999,oldPrice:39999,rating:4.8,badge:"BESTSELLER",desc:"55-inch 4K UHD • Smart apps",specs:"4K UHD, HDR, Wi-Fi, 3 HDMI",image:"https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=700&q=85",bg:"#f0efff"},
 {id:2,name:"CinemaLite 43” Smart TV",category:"TV",price:21999,oldPrice:26999,rating:4.6,badge:"POPULAR",desc:"43-inch Full HD • Voice remote",specs:"Full HD, Wi-Fi, 2 HDMI",image:"https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&w=700&q=85",bg:"#f5f3ff"},
 {id:3,name:"Nova X Pro Smartphone",category:"Mobile",price:24999,oldPrice:28999,rating:4.7,badge:"NEW",desc:"AMOLED display • 5G ready",specs:"128 GB, 5G, OLED display",image:"https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=700&q=85",bg:"#f0f6ff"},
 {id:4,name:"Pulse Mini Smartphone",category:"Mobile",price:14999,oldPrice:17999,rating:4.5,badge:"VALUE PICK",desc:"Bright display • All-day battery",specs:"128 GB, dual SIM, fast charge",image:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=700&q=85",bg:"#fff4ed"},
 {id:5,name:"Studio Wireless Headphones",category:"Accessory",price:2999,oldPrice:3999,rating:4.8,badge:"TOP RATED",desc:"Wireless audio • Soft ear cushions",specs:"Bluetooth, 30-hour battery",image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=85",bg:"#fff1e8"},
 {id:6,name:"AirBeat Earbuds",category:"Accessory",price:1799,oldPrice:2499,rating:4.6,badge:"DEAL",desc:"Compact case • Clear sound",specs:"Bluetooth 5, touch controls",image:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=700&q=85",bg:"#f0f7ff"},
 {id:7,name:"FitTrack Smart Watch",category:"Accessory",price:3499,oldPrice:4499,rating:4.4,badge:"SMART PICK",desc:"Activity tracking • Bright screen",specs:"Fitness modes, notifications",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=85",bg:"#f4f1ff"},
 {id:8,name:"Volt 20W Fast Charger",category:"Accessory",price:799,oldPrice:999,rating:4.5,badge:"ESSENTIAL",desc:"Compact charger • USB-C",specs:"20W output, USB-C, compact",image:"https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=700&q=85",bg:"#f2f4f7"}
];
const rupee = n => "₹" + n.toLocaleString("en-IN");
let activeCategory = "All";
let cart = [];
const grid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const toast = document.getElementById("toast");

function renderProducts(){
  let list = products.filter(p => (activeCategory==="All" || p.category===activeCategory) && (p.name+" "+p.desc+" "+p.specs).toLowerCase().includes(searchInput.value.toLowerCase().trim()));
  if(sortSelect.value==="low") list.sort((a,b)=>a.price-b.price);
  if(sortSelect.value==="high") list.sort((a,b)=>b.price-a.price);
  grid.innerHTML = list.length ? list.map(p=>`
    <article class="product-card">
      <div class="product-image" style="--product-bg:${p.bg}">
        <span class="product-badge">${p.badge}</span>
        <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('image-fallback');this.parentElement.insertAdjacentHTML('beforeend','<span class=&quot;fallback-icon&quot;>▣</span>')">
      </div>
      <div class="product-info">
        <span class="product-category">${p.category==="TV"?"Smart TV":p.category==="Mobile"?"Smartphone":"Accessories"}</span>
        <h3>${p.name}</h3><p class="product-desc">${p.desc}</p>
        <div class="product-meta"><span class="stars">★★★★★ <span style="color:#7a8191">${p.rating}</span></span><span><span class="price">${rupee(p.price)}</span> <span class="old-price">${rupee(p.oldPrice)}</span></span></div>
        <button class="add-btn" onclick="addToCart(${p.id})">＋ Add to cart</button>
      </div>
    </article>`).join("") : `<div class="empty-cart" style="grid-column:1/-1">No products found. Try another search.</div>`;
}
function showToast(message){
  toast.textContent=message;toast.classList.add("show");
  clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>toast.classList.remove("show"),2300);
}
function addToCart(id){
  const item=cart.find(x=>x.id===id);
  if(item)item.qty++;else cart.push({id,qty:1});
  updateCart();showToast("Added to your demo cart!");
}
function changeQty(id,delta){
  const item=cart.find(x=>x.id===id);if(!item)return;
  item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.id!==id);
  updateCart();
}
function removeItem(id){cart=cart.filter(x=>x.id!==id);updateCart();}
function updateCart(){
  const count=cart.reduce((sum,x)=>sum+x.qty,0);
  document.getElementById("cartCount").textContent=count;
  const items=document.getElementById("cartItems");
  if(!cart.length){items.innerHTML='<div class="empty-cart">🛒<br><br>Your cart is empty.<br>Add something you like!</div>';}
  else items.innerHTML=cart.map(item=>{
    const p=products.find(x=>x.id===item.id);
    return `<div class="cart-item"><img src="${p.image}" alt=""><div><h4>${p.name}</h4><p>${rupee(p.price)}</p><div class="qty-control"><button onclick="changeQty(${p.id},-1)" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button onclick="changeQty(${p.id},1)" aria-label="Increase quantity">+</button></div></div><button class="remove-btn" onclick="removeItem(${p.id})">Remove</button></div>`;
  }).join("");
  const total=cart.reduce((sum,item)=>sum+products.find(p=>p.id===item.id).price*item.qty,0);
  document.getElementById("cartTotal").textContent=rupee(total);
}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("cartOverlay").classList.add("show");document.getElementById("cartDrawer").setAttribute("aria-hidden","false");document.body.style.overflow="hidden";}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("cartOverlay").classList.remove("show");document.getElementById("cartDrawer").setAttribute("aria-hidden","true");document.body.style.overflow="";}
document.getElementById("openCart").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
document.getElementById("cartOverlay").addEventListener("click",closeCart);
document.getElementById("checkoutBtn").addEventListener("click",()=>showToast(cart.length?"Demo checkout only — no payment taken.":"Your cart is empty."));
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");activeCategory=btn.dataset.category;renderProducts();
}));
searchInput.addEventListener("input",renderProducts);
sortSelect.addEventListener("change",renderProducts);
document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();const name=document.getElementById("customerName").value.trim();
  document.getElementById("formStatus").textContent=`Thanks, ${name}! This is a demo form; no message was sent to a server.`;
  e.target.reset();
});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("mainNav").classList.toggle("show"));
document.querySelectorAll("#mainNav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("mainNav").classList.remove("show")));
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();updateCart();
