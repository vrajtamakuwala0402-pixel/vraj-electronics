VRAJ ELECTRONICS — COLLEGE PRACTICAL WEBSITE

Files:
- index.html : page structure/content
- style.css  : design and responsive layout
- script.js  : product list, category filters, search, sorting and demo cart

HOW TO RUN:
1. Extract vraj_electronics_website.zip.
2. Open the extracted folder.
3. Double-click index.html. It should open in Chrome/Edge.
4. Internet is needed for the sample product photos hosted by Unsplash. The site itself is plain HTML/CSS/JavaScript.

HOW TO PUT IT ONLINE USING GITHUB PAGES:
1. Sign in to GitHub and create a new public repository, for example vraj-electronics.
2. Upload index.html, style.css and script.js to the top level of the repository.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
5. Wait for the site to publish. GitHub will show the website URL in Settings > Pages.

COLLEGE PRACTICAL POINTS:
- HTML builds the page structure.
- CSS controls colours, spacing, layout and mobile responsiveness.
- JavaScript renders products and makes category filters, search, sort, cart quantity controls and demo contact form work.
- The products, prices, ratings and reviews are sample data.
- The cart is only in browser memory; it resets when the page is refreshed.
- No real payment, order processing, account login or server/database is connected.
- Contact form only displays a demo confirmation and does not send email.

Gujarati:
Aa project college practical mate chhe. index.html open karsho to website browser ma chalshe.
Product add karvu, search/filter, price sort, cart quantity badalvi ane contact form nu demo kaam kare chhe.
Aa demo website chhe — real payment ke real order nathi thato.
